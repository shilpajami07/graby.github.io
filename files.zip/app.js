// ===== GRABBY MAIN APP JS =====

// ---- NAVBAR ----
window.addEventListener('scroll', () => {
  const nav = document.getElementById('navbar');
  if (nav) nav.classList.toggle('scrolled', window.scrollY > 10);
});

function toggleMobileMenu() {
  const menu = document.getElementById('mobileMenu');
  if (menu) menu.classList.toggle('open');
}

// ---- SEARCH ----
function handleNavSearch() {
  const val = document.getElementById('navSearchInput')?.value;
  if (val) window.location.href = `listings.html?q=${encodeURIComponent(val)}`;
}
function handleHeroSearch() {
  const val = document.getElementById('heroSearch')?.value;
  const cat = document.getElementById('heroCategory')?.value;
  let url = 'listings.html';
  const params = [];
  if (val) params.push(`q=${encodeURIComponent(val)}`);
  if (cat) params.push(`cat=${encodeURIComponent(cat)}`);
  if (params.length) url += '?' + params.join('&');
  window.location.href = url;
}
function quickSearch(term) {
  window.location.href = `listings.html?q=${encodeURIComponent(term)}`;
}
document.addEventListener('keydown', e => {
  if (e.key === 'Enter') {
    if (document.activeElement?.id === 'navSearchInput') handleNavSearch();
    if (document.activeElement?.id === 'heroSearch') handleHeroSearch();
  }
});

// ---- CARD BUILDER ----
function buildListingCard(listing, size = 'normal') {
  const isFav = (GRABBY.USERS.currentUser?.favorites || []).includes(listing.id);
  const priceText = listing.price === 0 ? 'FREE' : `$${listing.price}`;
  const priceClass = listing.price === 0 ? 'free' : '';
  return `
    <div class="listing-card" onclick="openListingModal(${listing.id})">
      <div class="listing-img" style="background:${listing.bg}">
        ${listing.img}
        <span class="listing-condition">${listing.condition}</span>
        <button class="listing-fav ${isFav ? 'active' : ''}" onclick="toggleFav(event,${listing.id})" title="Save">
          ${isFav ? '♥' : '♡'}
        </button>
      </div>
      <div class="listing-body">
        <div class="listing-price ${priceClass}">${priceText}</div>
        <div class="listing-title">${listing.title}</div>
        <div class="listing-meta">
          <span class="listing-location">📍 ${listing.location}</span>
          <span>${listing.time}</span>
        </div>
        <div class="listing-seller">
          <div class="seller-av">${listing.sellerName.slice(0,2).toUpperCase()}</div>
          <div class="seller-info-row">
            <span class="seller-name-sm">${listing.sellerName}</span>
            <span class="seller-rating-sm">⭐ ${listing.sellerRating} · ${listing.views} views</span>
          </div>
        </div>
      </div>
    </div>`;
}

function buildTrendingCard(listing, rank) {
  return `
    <div class="trending-card" onclick="openListingModal(${listing.id})">
      <div class="trending-img" style="background:${listing.bg}">
        ${listing.img}
        <div class="trending-rank">${rank}</div>
      </div>
      <div class="trending-body">
        <div class="trending-price">${listing.price === 0 ? 'FREE' : '$'+listing.price}</div>
        <div class="trending-name">${listing.title}</div>
        <div class="trending-views">👁 ${listing.views} views</div>
      </div>
    </div>`;
}

// ---- HOMEPAGE RENDER ----
function renderFeatured() {
  const grid = document.getElementById('featuredGrid');
  if (!grid) return;
  grid.innerHTML = GRABBY.getFeatured().map(l => buildListingCard(l)).join('');
}

function renderTrending() {
  const scroll = document.getElementById('trendingScroll');
  if (!scroll) return;
  const trending = GRABBY.getTrending();
  scroll.innerHTML = trending.map((l, i) => buildTrendingCard(l, i + 1)).join('');
}

let recentCategory = 'all';
function renderRecent() {
  const grid = document.getElementById('recentGrid');
  if (!grid) return;
  let items = GRABBY.getRecent();
  if (recentCategory !== 'all') {
    items = items.filter(l =>
      l.tags.includes(recentCategory) ||
      l.category === recentCategory ||
      (recentCategory === 'home' && (l.tags.includes('home') || l.category === 'homegoods'))
    );
  }
  grid.innerHTML = items.slice(0, 8).map(l => buildListingCard(l)).join('');
}

function filterRecent(cat, btn) {
  recentCategory = cat;
  document.querySelectorAll('.filter-tab').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  renderRecent();
}

function loadMore() {
  showToast('Loading more listings...');
  setTimeout(() => {
    renderRecent();
    showToast('All listings loaded!');
  }, 800);
}

// ---- FAVORITES ----
function toggleFav(e, id) {
  e.stopPropagation();
  const user = GRABBY.USERS.currentUser;
  const idx = user.favorites.indexOf(id);
  if (idx === -1) {
    user.favorites.push(id);
    showToast('❤️ Saved to favorites');
  } else {
    user.favorites.splice(idx, 1);
    showToast('Removed from favorites');
  }
  const btn = e.currentTarget;
  btn.classList.toggle('active', idx === -1);
  btn.textContent = idx === -1 ? '♥' : '♡';
}

// ---- LISTING MODAL ----
function openListingModal(id) {
  const listing = GRABBY.getListingById(id);
  if (!listing) return;
  const modal = document.getElementById('listingModal');
  const content = document.getElementById('modalContent');
  const isFav = (GRABBY.USERS.currentUser?.favorites || []).includes(id);
  content.innerHTML = `
    <div class="modal-detail">
      <div class="modal-img" style="background:${listing.bg}">${listing.img}</div>
      <div class="modal-info">
        <div class="modal-price">${listing.price === 0 ? 'FREE' : '$'+listing.price}</div>
        <div class="modal-title">${listing.title}</div>
        <span class="modal-cond">${listing.condition}</span>
        <div class="modal-seller" onclick="window.location.href='profile.html?u=${listing.seller}'">
          <div class="modal-seller-av">${listing.sellerName.slice(0,2).toUpperCase()}</div>
          <div>
            <div class="modal-seller-name">${listing.sellerName} ${listing.sellerRating >= 4.8 ? '⭐' : ''}</div>
            <div class="modal-seller-stats">⭐ ${listing.sellerRating} · ${listing.sellerSales} sales · View profile →</div>
          </div>
        </div>
        <div class="modal-desc">${listing.desc}</div>
        <div class="modal-tags">
          <span class="modal-tag">📍 ${listing.location}</span>
          ${listing.shipping ? '<span class="modal-tag">📦 Shipping available</span>' : ''}
          ${listing.pickup ? '<span class="modal-tag">🤝 Local pickup</span>' : ''}
        </div>
        <div class="modal-actions">
          <button class="btn-primary" onclick="window.location.href='messages.html'">💬 Message seller</button>
          <button class="btn-secondary ${isFav ? 'fav-active' : ''}" id="modalFavBtn" onclick="modalToggleFav(${id})">
            ${isFav ? '❤️ Saved' : '♡ Save listing'}
          </button>
          <button class="btn-secondary" onclick="window.location.href='product.html?id=${id}'">View full details →</button>
        </div>
        <div class="modal-meta">
          <span>👁 ${listing.views} views</span>
          <span>❤️ ${listing.favorites} saves</span>
          <span>🕐 ${listing.time}</span>
        </div>
      </div>
    </div>`;
  modal.classList.add('open');
  document.body.style.overflow = 'hidden';
}

function modalToggleFav(id) {
  const user = GRABBY.USERS.currentUser;
  const idx = user.favorites.indexOf(id);
  const btn = document.getElementById('modalFavBtn');
  if (idx === -1) {
    user.favorites.push(id);
    btn.innerHTML = '❤️ Saved';
    showToast('❤️ Saved to favorites');
  } else {
    user.favorites.splice(idx, 1);
    btn.innerHTML = '♡ Save listing';
    showToast('Removed from favorites');
  }
}

function closeListingModal() {
  document.getElementById('listingModal')?.classList.remove('open');
  document.body.style.overflow = '';
}

function closeModal(e) {
  if (e.target === document.getElementById('listingModal')) closeListingModal();
}

document.addEventListener('keydown', e => {
  if (e.key === 'Escape') closeListingModal();
});

// ---- TOAST ----
function showToast(msg) {
  let toast = document.getElementById('grabbyToast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'grabbyToast';
    toast.className = 'toast';
    document.body.appendChild(toast);
  }
  toast.textContent = msg;
  toast.classList.add('show');
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => toast.classList.remove('show'), 2500);
}

// ---- INIT ----
document.addEventListener('DOMContentLoaded', () => {
  renderFeatured();
  renderTrending();
  renderRecent();
});
